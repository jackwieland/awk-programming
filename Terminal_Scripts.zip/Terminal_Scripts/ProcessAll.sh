#!/bin/sh

SCRIPT_DIR="$(dirname $(realpath "$0") )"

for PAT in $(seq 1 50); do 
	echo "Processing patient: ${PAT}"
	sh "${SCRIPT_DIR}/Processing_CNV_annot.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_SV_annot.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_InDel_CDS_annot.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_InDel_annot.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_SNP_CDS_annot.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_SNP_annot_part_1.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_SNP_annot_part_2.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_SNP_annot_part_3.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_SNP_annot_part_4.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_SNP_annot_part_5.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_CNV_Clin_Associations.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_SV_Clin_Associations.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_InDel_Clin_Associations.sh" ${PAT}
	sh "${SCRIPT_DIR}/Processing_SNP_Clin_Associations.sh" ${PAT}
done
