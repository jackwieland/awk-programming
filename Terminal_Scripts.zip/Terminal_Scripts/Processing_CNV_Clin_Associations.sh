#!/bin/sh
if [ $# -eq 1 ] ; then
	PAT="${1}"
else
	echo "Provide patient number to process"
	exit 1
fi

# Detect script directory and set BASEDIR,INDIR,OUTDIR
SCRIPTDIR="$(dirname $(realpath "$0") )"
SCRIPTNAME="$(basename "$0")"
BASEDIR="${SCRIPTDIR%/*}"
INDIR="${BASEDIR}/txt_inputs"
OUTDIR="${BASEDIR}/output/"

INFILE="${INDIR}/CNV/patient_${PAT}_cnv_gene_clin.txt"

if ! [ -f "${INFILE}" ]; then echo "${SCRIPTNAME}: Input file ${INFILE} does not exist."; exit 1; fi

OUTFILE="Patient_${PAT}_CNV_Gene_Clinical_Associations.csv"
mkdir -p "${OUTDIR}"
cat "${INFILE}" \
	| awk '
		BEGIN{ FS="\t"; OFS="\t"; };
		$5 {parent_id = $1; gene = $2; cancer = $3; OMIM = $4; FS=";"; $0 = $5; };
		{ for(i=1; i<=NF; i++){ print parent_id, gene, cancer, OMIM, $i ; } };
		{ FS="\t"; };' \
	| awk '
		BEGIN{FS="\t";OFS="\t"; re=", [[:digit:]]+ \\([[:digit:]]\\)[[:space:]]*$";};
		{
			sub(/[[:space:]]+$/,"",$5);
			if(match($5,re)) {
				$4=substr($5,RSTART+2,RLENGTH-6);
				$5=substr($5,1,RSTART-1) substr($5,RSTART+RLENGTH-4);
			};
			print
		};' \
	> "${OUTDIR}${OUTFILE}"