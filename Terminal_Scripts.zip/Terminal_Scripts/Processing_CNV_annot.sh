#!/bin/sh
if [ $# -eq 1 ] ; then
	PAT="${1}"
else
	echo "Provide patient number to process"
	exit 1
fi

# Detect script directory and set BASEDIR,INDIR,OUTDIR
SCRIPTDIR="$(dirname $(realpath "$0") )"
SCRIPTNAME="$(basename "$0")"
BASEDIR="${SCRIPTDIR%/*}"
INDIR="${BASEDIR}/txt_inputs"
OUTDIR="${BASEDIR}/output/"

# Input file = patient_x_cnv_gene_annot.txt
INFILE="${INDIR}/CNV/patient_${PAT}_cnv_gene_annot.txt"

if ! [ -f "${INFILE}" ]; then echo "${SCRIPTNAME}: Input file ${INFILE} does not exist."; exit 1; fi

mkdir -p "${OUTDIR}"
# Input Columns:
#  1: Func
#  2: Gene
#  3: Biotype
#  4: Transcript
#  5: Exon|Intron
#  6: Exon_Type
#  7: .
#  8: .
#  9: .
# 10: DGV
# 11: .
# 12: .
# 13: .
# 14: .
# 15: .
# 16: Chr
# 17: Start
# 18: End
# 19: Copy_Ratio
# 20: Type
# 21: Otherinfo
# 22: Isoform

#Output 1

# output file= Patient_x_CNV_Gene_Annotation.csv
OUTFILE="Patient_${PAT}_CNV_Gene_Annotation.csv"

# Output format:

#  1:*  Parent_ID
#  2:2  Gene 
#  3:3  Biotype
#  4:1  Func
#  5:*  Coordinates
#  6:4  Transcript
#  7:5  Exon|Intron
#  8:6  Exon_Type
#  9:20 Type
# 10:19 Copy_Ratio
# 11:10 DGV


# Programme 1
cat "${INFILE}" \
	| awk -v PatID="${PAT}" '
		BEGIN {FS = "\t"; OFS= "\t"; };
		NR==1 { print "Parent_ID", $2, $3, $1, "Coordinates", $4, $5, $6, $20, $19, $10 };
		NR>1 {
			loc = $16 ":" $17 "-" $18; 
			print PatID, $2, $3, $1, loc, $4, $5, $6, $20, $19, $10;
		};' \
	> "${OUTDIR}${OUTFILE}"


#-----------------------------------------------------------------------------------------------------

# Output 2

# output = Patient_x_CNV_Gene_Isoform.csv
OUTFILE="Patient_${PAT}_CNV_Gene_Isoform.csv"

# Output format:

#  1:* Parent_ID
#  2:2 Gene
#  3:* Coordinates
#  4:22* Isoform

# Programme 2
cat "${INFILE}" \
	| awk -v PatID="${PAT}" '
		BEGIN {FS = "\t"; OFS= "\t"; };
		NR==1 { print "Parent_ID", $2, "Coordinates", $22 };
		NR>1 && $22 {
			gene = $2;
			loc = $16 ":" $17 "-" $18;
			FS=";";
			$0 = $22;
		};
		NR>1 { for(i=1; i<=NF; i++) { print PatID, gene, loc, $i; } };
		{ FS="\t"; };' \
	> "${OUTDIR}${OUTFILE}"