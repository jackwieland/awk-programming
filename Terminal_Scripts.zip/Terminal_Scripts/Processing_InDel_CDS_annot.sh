#!/bin/sh
if [ $# -eq 1 ] ; then
	PAT="${1}"
else
	echo "Provide patient number to process"
	exit 1
fi

# Detect script directory and set BASEDIR,INDIR,OUTDIR
SCRIPTDIR="$(dirname $(realpath "$0") )"
SCRIPTNAME="$(basename "$0")"
BASEDIR="${SCRIPTDIR%/*}"
INDIR="${BASEDIR}/txt_inputs"
OUTDIR="${BASEDIR}/output/"

# Input file = patient_x_indel_cds_gene_annot.txt
INFILE="${INDIR}/InDel/InDel_CDS/patient_${PAT}_indel_cds_gene_annot.txt"

if ! [ -f "${INFILE}" ]; then echo "${SCRIPTNAME}: Input file ${INFILE} does not exist."; exit 1; fi

mkdir -p "${OUTDIR}"

# Input Columns:
# Func
# Gene
# Biotype
# Transcript
# .
# Impact
# COSMIC
# 1000G_ALL
# 1000G_EAS
# dbSNPv151_hg19/dbSNPv149_hg19
# . 
# .
# .
# .
# LOF|NMD
# Chr
# Start
# End
# Ref
# Obs
# Otherinfo
# isoform
# ENCODE
# REPEAT
# Clinvar
#
# 1000G_SAS
# 1000G_AMR
# 1000G_EUR
# ESP6500_ALL
# ESP6500_AA
# ESP6500_EA
# ExAC_ALL
# ExAC_AFR
# ExAC_AMR
# ExAC_EAS
# ExAC_FIN
# ExAC_NFE
# ExAC_OTH
# ExAC_SAS

# Output 1

# output file= Patient_x_InDel_CDS_Gene_Annotation.csv
OUTFILE="Patient_${PAT}_InDel_CDS_Gene_Annotation.csv"

# Output format:
# 1:* Parent_ID
# 2:2 Gene
# 3:* Coordinates
# 10:4 dbSNP
# 1:5 Func
# 4:6 Transcript
# 6:7 Impact
# 7:8 COSMIC
# 15:9 LOF|NMD
# 19:10 Ref
# 20:11 Obs
# 24:12 REPEAT
# 21:13 Otherinfo

# Programme 1
cat "${INFILE}" \
	| awk -v PatID="${PAT}" '
		BEGIN {FS = "\t"; OFS= "\t"; };
		NR==1 { print "Parent_ID", $2, $3, "Coordinates", $10, $1, $4, $6, $7, $15, $19, $20, $24, $21 };
		NR>1 {
			loc = $16 ":" $17 "-" $18; 
			print PatID, $2, $3, loc, $10, $1, $4, $6, $7, $15, $19, $20, $24, $21;
		};' \
	> "${OUTDIR}${OUTFILE}"
	
			
# -------------------------------------------------------------------------------------------------------------			
			
# Output 2

# output = Patient_x_InDel_CDS_Gene_Population_Genetics.csv
OUTFILE="Patient_${PAT}_InDel_CDS_Gene_Population_Genetics.csv"

# Output format:
# 1:* Parent_ID
# 2:2 Gene
# 3:* Coordinates
# 10:4 dbSNP
# 8:5 1000G_ALL
# 9:6 1000G_EAS
# 27:7 1000G_SAS
# 28:8 1000G_AMR
# 29:9 1000G_EUR
# 30:10 ESP6500_ALL
# 31:11 ESP6500_AA
# 32:12 ESP6500_EA
# 33:13 ExAC_ALL
# 34:14 ExAC_AFR
# 35:15 ExAC_AMR
# 36:16 ExAC_EAS
# 37:17 ExAC_FIN
# 38:18 ExAC_NFE
# 39:19 ExAC_OTH
# 40:20 ExAC_SAS

# Programme 2
cat "${INFILE}" \
	| awk -v PatID="${PAT}" '
		BEGIN {FS = "\t"; OFS= "\t"; };
		NR==1 { print "Parent_ID", $2, "Coordinates", $10, $8, $9, $27, $28, $29, $30, $31, $32, $33, $34, $35, $36, $37, $38, $39, $40 };
		NR>1 {
			loc = $16 ":" $17 "-" $18; 
			print PatID $2, loc, $10, $8, $9, $27, $28, $29, $30, $31, $32, $33, $34, $35, $36, $37, $38, $39, $40
		};' \
	> "${OUTDIR}${OUTFILE}"
	
# --------------------------------------------------------------------------------------------------------

# Output 3

# Output = Patient_x_InDel_CDS_Isoforms
OUTFILE="Patient_${PAT}_InDel_CDS_Gene_Isoform.csv"

# Output format:

#  1:* Parent_ID
#  2:2 Gene
#  3:* Coordinates
#  4:22 Isoform

# Programme 3
cat "${INFILE}" \
	| awk -v PatID="${PAT}" '
		BEGIN {FS = "\t"; OFS= "\t"; };
		NR==1 { print "Parent_ID", $2, "Coordinates", $22 };
		NR>1 && $22 {
			gene = $2;
			loc = $16 ":" $17 "-" $18;
			FS=",";
			$0 = $22;
		};
		NR>1 { for(i=1; i<=NF; i++) { print PatID, gene, loc, $i; } };
		{ FS="\t"; };' \
	> "${OUTDIR}${OUTFILE}"			