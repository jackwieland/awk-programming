#!/bin/sh
if [ $# -eq 1 ] ; then
	PAT="${1}"
else
	echo "Provide patient number to process"
	exit 1
fi

# Detect script directory and set BASEDIR,INDIR,OUTDIR
SCRIPTDIR="$(dirname $(realpath "$0") )"
SCRIPTNAME="$(basename "$0")"
BASEDIR="${SCRIPTDIR%/*}"
INDIR="${BASEDIR}/txt_inputs"
OUTDIR="${BASEDIR}/output/"

# Input file = patient_x_snp_gene_annot_4.txt
INFILE="${INDIR}/SNP/patient_${PAT}_snp_gene_annot_part_5.txt"

if ! [ -f "${INFILE}" ]; then echo "${SCRIPTNAME}: Input file ${INFILE} does not exist."; exit 1; fi

mkdir -p "${OUTDIR}"

# Input Columns:
# Func
# Gene
# Exonic|Biotype
# Transcript
# Codon_Change
# Impact
# COSMIC
# 1000G_ALL
# 1000G_EAS
# dbSNPv151/149_hg19
# SIFT
# PolyPhen2
# MutationAssessor
# MetaSVM
# LOF|NMD
# Chr
# Start
# End
# Ref
# Obs
# Otherinfo
# isoform
# ENCODE
# HGMD
# Clinvar
# GWAS
# 1000G_SAS
# 1000G_AMR
# 1000G_EUR
# ESP6500_ALL
# ESP6500_AA
# ESP6500_EA
#
# LRT
# MutationTaster
# FATHMM
# MetaLR
# VEST3
# CADD
# GERP++_NR
# GERP++_RS
# phyloP20way_mammalian
# phyloP100way_vertebrate
# phastCons20way_mammalian
# phastCons100way_vertebrate
# SiPhy_29way_logOdds
#
# ExAC_ALL
# ExAC_AFR
# ExAC_AMR
# ExAC_EAS
# ExAC_FIN
# ExAC_NFE
# ExAC_OTH
# ExAC_SAS

# Output 1

# Output = Patient_x_SNP_Gene_Annotation
OUTFILE="Patient_${PAT}_SNP_Gene_Annotation_Part_5.csv"

# Output format:
# 1:* Parent_ID
# 2:2 Gene
# 1:3 Func
# 3:4 Exonic|Biotype
# 5:* Coordinates
# 10:6 dbSNP
# 4:7 Transcript
# 5:8 Codon_Change
# 6:9 Impact
# 7:10 COSMIC
# 15:11 LOF|NMD
# 19:12 Ref
# 20:13 Obs
# 21:14 Otherinfo

# Programme 1
cat "${INFILE}" \
	| awk -v PatID="${PAT}" '
		BEGIN {FS = "\t"; OFS= "\t"; };
		NR==1 { print "Parent_ID", $2, $1, $3, "Coordinates", $10, $4, $5, $6, $7, $15, $19, $20, $21 };
		NR>1 {
			loc = $16 ":" $17 "-" $18; 
			print PatID, $2, $1, $3, loc, $10, $4, $5, $6, $7, $15, $19, $20, $21;
		};' \
	> "${OUTDIR}${OUTFILE}"

# --------------------------------------------------------------------------------------------------------

# Output 2			

# output = Patient_x_SNP_Gene_Population_Genetics.csv
OUTFILE="Patient_${PAT}_SNP_Gene_Population_Genetics_Part_5.csv"

# Output format:
# 1:* Parent_ID
# 2:2 Gene
# 3:* Coordinates
# 10:4 dbSNP
# 8:5 1000G_ALL
# 9:6 1000G_EAS
# 27:10 1000G_SAS
# 28:11 1000G_AMR
# 29:12 1000G_EUR
# 30:13 ESP6500_ALL
# 31:14 ESP6500_AA
# 32:15 ESP6500_EA
# 48:16 ExAC_ALL
# 49:17 ExAC_AFR
# 50:18 ExAC_AMR
# 51:19 ExAC_EAS
# 52:20 ExAC_FIN
# 53:21 ExAC_NFE
# 54:22 ExAC_OTH
# 55:23 ExAC_SAS

# Programme 2
cat "${INFILE}" \
	| awk -v PatID="${PAT}" '
		BEGIN {FS = "\t"; OFS= "\t"; };
		NR==1 { print "Parent_ID", $2, "Coordinates", $10, $8, $9, $27, $28, $29, $30, $31, $32, $48, $49, $50, $51, $52, $53, $54, $55 };
		NR>1 {
			loc = $16 ":" $17 "-" $18; 
			print PatID , $2, loc, $10, $8, $9, $27, $28, $29, $30, $31, $32, $48, $49, $50, $51, $52, $53, $54, $55;
		};' \
	> "${OUTDIR}${OUTFILE}"
	
# -----------------------------------------------------------------------------------------------------------

# Output 3

# Output = Patient_x_SNP_Gene_Isoforms
OUTFILE="Patient_${PAT}_SNP_Gene_Isoform_Part_5.csv"

# Output format:
#  1:* Parent_ID
#  2:2 Gene
#  3:* Coordinates
#  4:22 Isoform

# Programme 3
cat "${INFILE}" \
	| awk -v PatID="${PAT}" '
		BEGIN {FS = "\t"; OFS= "\t"; };
		NR==1 { print "Parent_ID", $2, "Coordinates", $22 };
		NR>1 && $22 {
			gene = $2;
			loc = $16 ":" $17 "-" $18;
			FS=",";
			$0 = $22;
		};
		NR>1 { for(i=1; i<=NF; i++) { print PatID, gene, loc, $i; } };
		{ FS="\t"; };' \
	> "${OUTDIR}${OUTFILE}"