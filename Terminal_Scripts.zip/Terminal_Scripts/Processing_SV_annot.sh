#!/bin/sh
if [ $# -eq 1 ] ; then
	PAT="${1}"
else
	echo "Provide patient number to process"
	exit 1
fi

# Detect script directory and set BASEDIR,INDIR,OUTDIR
SCRIPTDIR="$(dirname $(realpath "$0") )"
SCRIPTNAME="$(basename "$0")"
BASEDIR="${SCRIPTDIR%/*}"
INDIR="${BASEDIR}/txt_inputs"
OUTDIR="${BASEDIR}/output/"

# Input file = patient_x_sv_gene_annot.txt
INFILE="${INDIR}/SV/patient_${PAT}_sv_gene_annot.txt"

if ! [ -f "${INFILE}" ]; then echo "${SCRIPTNAME}: Input file ${INFILE} does not exist."; exit 1; fi

mkdir -p "${OUTDIR}"
# Input Columns:
# Func
# Gene
# Biotype
# Transcript
# Exon|Intron
# Exon_Type
# .
# .
# .
# .
# .
# .
# .
# .
# .
# Chr
# Start
# End
# ID
# Type
# Otherinfo
# Isoform

#Output 1

# output file= Patient_x_SV_Gene_Annotation.csv
OUTFILE="Patient_${PAT}_SV_Gene_Annotation.csv"

# Output format
# 1:* Parent_ID
# 2:2 Gene
# 3:3 Biotype
# 1:4 Func
# 5:* Coordinates
# 4:6 Transcript
# 5:7 Exon|Intron
# 6:8 Exon_Type
# 20:9 Type

# Programme 1
cat "${INFILE}" \
	| awk -v PatID="${PAT}" '
		BEGIN {FS = "\t"; OFS= "\t"; };
		NR==1 { print "Parent_ID", $2, $3, $1, "Coordinates", $4, $5, $6, $20 };
		NR>1 {
			loc = $16 ":" $17 "-" $18; 
			print PatID, $2, $3, $1, loc, $4, $5, $6, $20;
		};' \
	> "${OUTDIR}${OUTFILE}"

#-----------------------------------------------------------------------------------------------------

# Output 2

# output = Patient_x_SV_Gene_Isoform.csv
OUTFILE="Patient_${PAT}_SV_Gene_Isoform.csv"

# Output format:

#  1:* Parent_ID
#  2:2 Gene
#  3:* Coordinates
#  4:22 Isoform

# Programme 2
cat "${INFILE}" \
	| awk -v PatID="${PAT}" '
		BEGIN {FS = "\t"; OFS= "\t"; };
		NR==1 { print "Parent_ID", $2, "Coordinates", $22 };
		NR>1 && $22 {
			gene = $2;
			loc = $16 ":" $17 "-" $18;
			FS=";";
			$0 = $22;
		};
		NR>1 { for(i=1; i<=NF; i++) { print PatID, gene, loc, $i; } };
		{ FS="\t"; };' \
	> "${OUTDIR}${OUTFILE}"